/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * FacetimeHD camera driver
 *
 * Copyright (C) 2014 Patrik Jakobsson (patrik.r.jakobsson@gmail.com)
 *
 */

#ifndef _FTHD_DRV_H
#define _FTHD_DRV_H

#include <linux/pci.h>
#include <linux/ktime.h>
#include <linux/workqueue.h>
#include <linux/spinlock.h>
#include <linux/wait.h>
#include <linux/mutex.h>
#include <linux/version.h>
#include <media/videobuf2-dma-sg.h>
#include <media/v4l2-device.h>
#include <media/v4l2-ctrls.h>
#include "fthd_reg.h"
#include "fthd_ringbuf.h"
#include "fthd_buffer.h"
#include "fthd_v4l2.h"

/* system_dfl_wq was added in 6.17; before that it was system_unbound_wq */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 17, 0)
#define system_dfl_wq system_unbound_wq
#endif

#define FTHD_PCI_S2_IO  0
#define FTHD_PCI_S2_MEM 2
#define FTHD_PCI_ISP_IO 4

#define FTHD_BUFFERS 8

/* Power cycles tried before the camera is declared dead until reopened */
#define FTHD_RECOVER_ATTEMPTS 3
/* No frame for this long with buffers at the firmware means it hangs */
#define FTHD_FRAME_TIMEOUT_MS 2000

enum fthd_hw_state {
	FTHD_HW_DOWN,		/* firmware not running, channels released */
	FTHD_HW_STARTING,	/* bring-up in progress */
	FTHD_HW_UP,		/* firmware running */
	FTHD_HW_FAILED,		/* firmware stopped responding */
};

#define FTHD_FRAME_RATE_SCALE 256U
#define FTHD_FRAME_RATE_MIN (2 * FTHD_FRAME_RATE_SCALE)
#define FTHD_FRAME_RATE_MAX (30 * FTHD_FRAME_RATE_SCALE)

enum FW_CHAN_TYPE {
	FW_CHAN_TYPE_OUT=0,
	FW_CHAN_TYPE_IN=1,
	FW_CHAN_TYPE_UNI_IN=2,
};

struct fw_channel {
	u32 offset;
	u32 size;
	u32 source;
	u32 type;
	struct fthd_ringbuf ringbuf;
	spinlock_t lock;
	/* waitqueue for signaling completion */
	wait_queue_head_t wq;
	char *name;
};

struct fthd_private {
	struct pci_dev *pdev;
	unsigned int dma_mask;

	struct v4l2_device v4l2_dev;
	struct video_device *videodev;
	struct mutex ioctl_lock;
	atomic_t users;
	/* lock for synchronizing with irq/workqueue */
	spinlock_t io_lock;

	/* Mapped PCI resources */
	void __iomem *s2_io;
	u32 s2_io_len;

	void __iomem *s2_mem;
	u32 s2_mem_len;

	void __iomem *isp_io;
	u32 isp_io_len;

	struct work_struct irq_work;

	/* Hardware info */
	u32 core_clk;
	u32 ddr_model;
	u32 ddr_speed;
	u32 vdl_step_size;

	u32 ddr_phy_regs[DDR_PHY_NUM_REG];

	/* Root resource for memory management */
	struct resource *mem;
	/* Resource for managing IO mmu slots */
	struct resource *iommu;
	/* ISP memory objects */
	struct isp_mem_obj *firmware;
	struct isp_mem_obj *set_file;
	struct isp_mem_obj *ipc_queue;
	struct isp_mem_obj *heap;
	struct isp_mem_obj *fw_args;

	/* Firmware channels */
	int num_channels;
	struct fw_channel **channels;
	struct fw_channel *channel_terminal;
	struct fw_channel *channel_io;
	struct fw_channel *channel_debug;
	struct fw_channel *channel_buf_h2t;
	struct fw_channel *channel_buf_t2h;
	struct fw_channel *channel_shared_malloc;
	struct fw_channel *channel_io_t2h;

	/* camera config */
	int sensor_count;
	int sensor_id0;
	int sensor_id1;
	/* Native sensor resolution, read from the firmware's per-channel camera
	 * config. MacBookPro sensors report 1280x720; the 12-inch MacBook
	 * (MacBook8,1, sensor 1675) reports 848x588. 0 until detected. */
	unsigned int sensor_width;
	unsigned int sensor_height;

	struct fthd_fmt fmt;

	struct vb2_queue vb2_queue;
	struct mutex vb2_queue_lock;
	struct list_head buffer_queue;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
	struct vb2_alloc_ctx *alloc_ctx;
#endif
	struct h2t_buf_ctx h2t_bufs[FTHD_BUFFERS];

	struct v4l2_ctrl_handler v4l2_ctrl_handler;
	u32 frame_rate; /* 1/256 fps */
	int exposure_auto_priority;
	unsigned int sequence;
	struct dentry *debugfs;

	/* Hardware life cycle; changed only with vb2_queue_lock held */
	enum fthd_hw_state hw_state;
	bool suspended;
	bool resuming;
	bool streaming;
	bool removing;
	unsigned int recover_count;
	struct work_struct recover_work;
	struct delayed_work frame_watchdog;
	struct delayed_work idle_work;
	unsigned int hang_count;
	bool force_recover;

	/* Camera power through ACPI CMPE */
	struct pci_saved_state *pci_state;
	bool powered_off;
	bool fresh_power;
	ktime_t power_off_time;
	unsigned int power_cycles;
	s64 last_off_ms;
};

extern int fthd_hw_restart(struct fthd_private *dev_priv, bool power_cycle);
extern void fthd_schedule_recovery(struct fthd_private *dev_priv);
extern void fthd_hw_hung(struct fthd_private *dev_priv, const char *why);
extern void fthd_hw_halt(struct fthd_private *dev_priv);
extern void fthd_schedule_idle(struct fthd_private *dev_priv);

#endif

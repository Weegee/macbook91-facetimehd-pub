/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * FacetimeHD camera driver
 *
 * Copyright (C) 2015 Sven Schnelle <svens@stackframe.org>
 *
 */

#include <linux/kernel.h>
#include <linux/math64.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/version.h>
#include <linux/videodev2.h>
#include <media/v4l2-dev.h>
#include <media/v4l2-ioctl.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-event.h>
#include <media/videobuf2-dma-sg.h>
#include "fthd_drv.h"
#include "fthd_hw.h"
#include "fthd_isp.h"
#include "fthd_ringbuf.h"
#include "fthd_buffer.h"

/* Fallback ceiling used only if the sensor's native size wasn't detected.
 * The real per-device limit is dev_priv->sensor_width/height. */
#define FTHD_MAX_WIDTH 1280
#define FTHD_MAX_HEIGHT 720
#define FTHD_MIN_WIDTH 320
#define FTHD_MIN_HEIGHT 240
#define FTHD_NUM_FORMATS 2 /* NV16 is disabled for now */

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 7, 0)
# define VFL_TYPE_VIDEO VFL_TYPE_GRABBER
#endif

static int fthd_buffer_queue_setup(
    struct vb2_queue *vq,
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,4,0)
    const struct v4l2_format *fmt,
#endif
#if !(LINUX_VERSION_CODE >= KERNEL_VERSION(4,5,0))
    const void *parg,
#endif
    unsigned int *nbuffers,
    unsigned int *nplanes,
    unsigned int sizes[],
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,8,0)
    struct device *alloc_devs[]
#else
    void *alloc_ctxs[]
#endif
) {

	struct fthd_private *dev_priv = vb2_get_drv_priv(vq);
	struct v4l2_pix_format *cur_fmt = &dev_priv->fmt.fmt;
	unsigned long budget = 16 * 1024 * 1024;
	unsigned long size;
	unsigned int i, allocated, slots, limit;
	bool create = *nplanes != 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
	allocated = vb2_get_num_buffers(vq);
	slots = vq->max_num_buffers;
#else
	allocated = vq->num_buffers;
	slots = vq->num_buffers;
#endif
	if (create) {
		if (*nplanes != 1 || sizes[0] < cur_fmt->sizeimage)
			return -EINVAL;
	} else {
		*nplanes = 1;
		sizes[0] = cur_fmt->sizeimage;
	}

	size = PAGE_ALIGN((unsigned long)sizes[0]);
	if (!size)
		return -ENOMEM;

	if (create) {
		/*
		 * CREATE_BUFS asks for buffers on top of the ones already
		 * there, so those are charged against the budget and against
		 * the context count.
		 */
		for (i = 0; i < slots; i++) {
			struct vb2_buffer *vb;
			unsigned long used;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
			vb = vb2_get_buffer(vq, i);
#else
			vb = vq->bufs[i];
#endif
			if (!vb)
				continue;
			used = PAGE_ALIGN((unsigned long)vb2_plane_size(vb, 0));
			if (!used || used >= budget)
				return -ENOMEM;
			budget -= used;
		}
		if (allocated >= FTHD_BUFFERS)
			return -ENOBUFS;
		if (size > budget)
			return -ENOMEM;
		limit = min_t(unsigned int, FTHD_BUFFERS - allocated,
			      budget / size);
		*nbuffers = min(*nbuffers, limit);
		if (!*nbuffers)
			return -ENOMEM;
	} else {
		/*
		 * REQBUFS asks for a total. vb2 calls back a second time to
		 * confirm a partial allocation, and the buffers it asks about
		 * then are the ones already allocated, so charging them here
		 * would reject a count that is in fact usable.
		 */
		if (size > budget)
			return -ENOMEM;
		limit = min_t(unsigned int, FTHD_BUFFERS, budget / size);
		*nbuffers = min(max(*nbuffers, 2U), limit);
		if (*nbuffers < 2)
			return -ENOMEM;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 8, 0)
	alloc_devs[0] = &dev_priv->pdev->dev;
#else
	alloc_ctxs[0] = dev_priv->alloc_ctx;
#endif
	return 0;
}

/*
 * Frame watchdog: restarted whenever a buffer goes to the firmware or comes
 * back, so it only fires when the firmware holds buffers and stays silent.
 */
void fthd_frame_watchdog_kick(struct fthd_private *dev_priv)
{
	mod_delayed_work(system_dfl_wq, &dev_priv->frame_watchdog,
			 msecs_to_jiffies(FTHD_FRAME_TIMEOUT_MS));
}

void fthd_frame_watchdog_stop(struct fthd_private *dev_priv)
{
	cancel_delayed_work_sync(&dev_priv->frame_watchdog);
}

void fthd_frame_watchdog(struct work_struct *work)
{
	struct fthd_private *dev_priv = container_of(to_delayed_work(work),
					struct fthd_private, frame_watchdog);
	int i, held = 0;

	if (!READ_ONCE(dev_priv->streaming) ||
	    READ_ONCE(dev_priv->hw_state) != FTHD_HW_UP)
		return;

	for (i = 0; i < FTHD_BUFFERS; i++)
		if (READ_ONCE(dev_priv->h2t_bufs[i].state) == BUF_HW_QUEUED)
			held++;
	/* An application that keeps its buffers gets no frames either */
	if (!held)
		return;

	fthd_hw_hung(dev_priv, "no frames");
}

static struct h2t_buf_ctx *fthd_find_ctx(struct fthd_private *dev_priv,
					  struct vb2_buffer *vb)
{
	int i;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		if (dev_priv->h2t_bufs[i].vb == vb)
			return dev_priv->h2t_bufs + i;
	}
	return NULL;
}

/* Release the S2 side of a buffer: its descriptor and IOMMU mappings. */
static void fthd_ctx_unmap(struct fthd_private *dev_priv, struct h2t_buf_ctx *ctx)
{
	int i;

	for (i = 0; i < ARRAY_SIZE(ctx->plane); i++) {
		iommu_free(dev_priv, ctx->plane[i]);
		ctx->plane[i] = NULL;
	}
	isp_mem_destroy(ctx->dma_desc_obj);
	ctx->dma_desc_obj = NULL;
}

static void fthd_ctx_fill_desc(struct fthd_private *dev_priv, struct h2t_buf_ctx *ctx)
{
	struct dma_descriptor_list *dma_list = &ctx->dma_desc_list;

	memset(dma_list, 0, 0x180);

	dma_list->field0 = 1;
	dma_list->count = 1;
	dma_list->desc[0].count = 1;
	dma_list->desc[0].pool = 0x02;
	dma_list->desc[0].addr0 = ((ctx->plane[0]->offset << 12) | 0xc0000000) +
		ctx->plane[0]->byte_offset;

	if (dev_priv->fmt.planes >= 2)
		dma_list->desc[0].addr1 = ((ctx->plane[1]->offset << 12) | 0xc0000000) +
		ctx->plane[1]->byte_offset;
	if (dev_priv->fmt.planes >= 3)
		dma_list->desc[0].addr2 = ((ctx->plane[2]->offset << 12) | 0xc0000000) +
		ctx->plane[2]->byte_offset;

	dma_list->desc[0].tag = (u64)ctx;
}

/* Map a buffer into S2 memory. Needs a running chip. */
static int fthd_ctx_map(struct fthd_private *dev_priv, struct h2t_buf_ctx *ctx)
{
	struct sg_table *sgtable;
	int i;

	if (!dev_priv->mem || !dev_priv->iommu)
		return -EIO;

	ctx->dma_desc_obj = isp_mem_create(dev_priv, FTHD_MEM_BUFFER, 0x180);
	if (!ctx->dma_desc_obj)
		return -ENOMEM;

	for (i = 0; i < dev_priv->fmt.planes; i++) {
		sgtable = vb2_dma_sg_plane_desc(ctx->vb, i);
		ctx->plane[i] = iommu_allocate_sgtable(dev_priv, sgtable);
		if (!ctx->plane[i]) {
			fthd_ctx_unmap(dev_priv, ctx);
			return -ENOMEM;
		}
	}

	fthd_ctx_fill_desc(dev_priv, ctx);
	return 0;
}

static void fthd_buffer_cleanup(struct vb2_buffer *vb)
{
	struct fthd_private *dev_priv = vb2_get_drv_priv(vb->vb2_queue);
	struct h2t_buf_ctx *ctx;

	pr_debug("%p\n", vb);
	ctx = fthd_find_ctx(dev_priv, vb);
	if (!ctx || ctx->state == BUF_FREE)
		return;

	fthd_ctx_unmap(dev_priv, ctx);
	ctx->state = BUF_FREE;
	ctx->vb = NULL;
}

static int fthd_send_h2t_buffer(struct fthd_private *dev_priv, struct h2t_buf_ctx *ctx)
{
	u32 entry;
	int ret;

	pr_debug("sending buffer %p size %ld, ctx %p\n", ctx->vb, sizeof(ctx->dma_desc_list), ctx);
	FTHD_S2_MEMCPY_TOIO(ctx->dma_desc_obj->offset, &ctx->dma_desc_list, sizeof(ctx->dma_desc_list));
	ret = fthd_channel_ringbuf_send(dev_priv, dev_priv->channel_buf_h2t,
					ctx->dma_desc_obj->offset, 0x180, 0x30000000, &entry);

	if (ret) {
		pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);
		return ret;
	}
	return fthd_channel_wait_ready(dev_priv, dev_priv->channel_buf_h2t, entry, 2000);
}

static void fthd_buffer_queue(struct vb2_buffer *vb)
{
	struct fthd_private *dev_priv = vb2_get_drv_priv(vb->vb2_queue);
	struct dma_descriptor_list *list;
	struct h2t_buf_ctx *ctx;

	pr_debug("vb = %p\n", vb);
	ctx = fthd_find_ctx(dev_priv, vb);
	if (!ctx)
		return;

	if (ctx->state != BUF_ALLOC)
		return;

	/*
	 * Without a running channel the buffer waits in the driver; starting
	 * or restarting the stream hands it to the firmware.
	 */
	if (!dev_priv->streaming || dev_priv->hw_state != FTHD_HW_UP ||
	    !ctx->dma_desc_obj) {
		ctx->state = BUF_DRV_QUEUED;
		return;
	}

	list = &ctx->dma_desc_list;
	list->field0 = 1;
	ctx->state = BUF_HW_QUEUED;
	wmb();
	pr_debug("field0: %d, count %d, pool %d, addr0 0x%08x, addr1 0x%08x tag 0x%08llx vb = %p\n", list->field0,
		 list->desc[0].count, list->desc[0].pool, list->desc[0].addr0, list->desc[0].addr1, list->desc[0].tag, ctx->vb);

	if (fthd_send_h2t_buffer(dev_priv, ctx)) {
		ctx->state = BUF_ALLOC;
		vb2_buffer_done(vb, VB2_BUF_STATE_ERROR);
		return;
	}
	fthd_frame_watchdog_kick(dev_priv);
}

static int fthd_buffer_prepare(struct vb2_buffer *vb)
{
	struct fthd_private *dev_priv = vb2_get_drv_priv(vb->vb2_queue);
	struct h2t_buf_ctx *ctx = NULL;
	int i, ret;

	pr_debug("%p\n", vb);
	/* The firmware writes a whole frame of the current format */
	if (vb2_plane_size(vb, 0) < dev_priv->fmt.fmt.sizeimage)
		return -EINVAL;

	for(i = 0; i < FTHD_BUFFERS; i++) {
		if (dev_priv->h2t_bufs[i].state == BUF_FREE ||
		    (dev_priv->h2t_bufs[i].state == BUF_ALLOC && dev_priv->h2t_bufs[i].vb == vb)) {
			ctx = dev_priv->h2t_bufs + i;
			break;
		}
	}

	if (!ctx)
		return -ENOBUFS;

	if (ctx->state == BUF_FREE) {
		pr_debug("allocating new entry\n");
		ctx->vb = vb;
		ctx->state = BUF_ALLOC;
		init_waitqueue_head(&ctx->wq);
	}

	/* A buffer prepared while the chip is down is mapped on bring-up */
	if (!ctx->dma_desc_obj && dev_priv->hw_state == FTHD_HW_UP) {
		ret = fthd_ctx_map(dev_priv, ctx);
		if (ret) {
			ctx->vb = NULL;
			ctx->state = BUF_FREE;
			return ret;
		}
	} else if (ctx->dma_desc_obj) {
		fthd_ctx_fill_desc(dev_priv, ctx);
	}

	vb2_set_plane_payload(vb, 0, dev_priv->fmt.fmt.sizeimage);
	return 0;
}

static struct h2t_buf_ctx *fthd_tag_to_ctx(struct fthd_private *dev_priv, u64 tag)
{
	int i;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		if (tag == (u64)(dev_priv->h2t_bufs + i))
			return dev_priv->h2t_bufs + i;
	}
	return NULL;
}

void fthd_buffer_return_handler(struct fthd_private *dev_priv, u32 offset, int size)
{
	struct dma_descriptor_list list;
	struct h2t_buf_ctx *ctx;
	int i;

	FTHD_S2_MEMCPY_FROMIO(&list, offset, sizeof(list));

	if (list.count > ARRAY_SIZE(list.desc)) {
		dev_err_ratelimited(&dev_priv->pdev->dev,
				    "invalid buffer return count %u\n", list.count);
		return;
	}

	for(i = 0; i < list.count; i++) {
		/* The tag comes back from chip memory; only trust our own */
		ctx = fthd_tag_to_ctx(dev_priv, list.desc[i].tag);
		if (!ctx) {
			dev_err_ratelimited(&dev_priv->pdev->dev,
					    "invalid buffer tag %llx\n",
					    list.desc[i].tag);
			continue;
		}
		pr_debug("%d: field0: %d, count %d, pool %d, addr0 0x%08x, addr1 0x%08x tag 0x%08llx vb = %p, ctx = %p\n", i, list.field0,
			 list.desc[i].count, list.desc[i].pool, list.desc[i].addr0, list.desc[i].addr1, list.desc[i].tag, ctx->vb, ctx);

		if (ctx->state == BUF_HW_QUEUED || ctx->state == BUF_DRV_QUEUED) {
			struct vb2_v4l2_buffer *vbuf = to_vb2_v4l2_buffer(ctx->vb);

			vbuf->sequence = dev_priv->sequence++;
			vbuf->vb2_buf.timestamp = ktime_get_ns();
			vbuf->field = V4L2_FIELD_NONE;

			ctx->state = BUF_ALLOC;
			vb2_buffer_done(ctx->vb, VB2_BUF_STATE_DONE);
			fthd_frame_watchdog_kick(dev_priv);
		}

	}
}

/*
 * Start the firmware channel and hand it every buffer held by the driver.
 * Called with vb2_queue_lock held.
 */
int fthd_v4l2_stream_restart(struct fthd_private *dev_priv)
{
	struct h2t_buf_ctx *ctx;
	int i, ret;

	ret = fthd_start_channel(dev_priv, 0);
	if (ret)
		return ret;

	/* Starting the channel resets the ISP, so push the control values down. */
	__v4l2_ctrl_handler_setup(&dev_priv->v4l2_ctrl_handler);

	for(i = 0; i < FTHD_BUFFERS; i++) {
		ctx = dev_priv->h2t_bufs + i;
		if (ctx->state != BUF_DRV_QUEUED)
			continue;

		ctx->state = BUF_HW_QUEUED;
		if (fthd_send_h2t_buffer(dev_priv, ctx)) {
			ctx->state = BUF_ALLOC;
			vb2_buffer_done(ctx->vb, VB2_BUF_STATE_ERROR);
		}
	}
	fthd_frame_watchdog_kick(dev_priv);
	return 0;
}

/* The chip is going down; its S2 memory and IOMMU go with it. */
void fthd_v4l2_buffers_unmap(struct fthd_private *dev_priv)
{
	struct h2t_buf_ctx *ctx;
	int i;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		ctx = dev_priv->h2t_bufs + i;
		if (ctx->state == BUF_FREE)
			continue;
		/* The firmware forgets it, the driver sends it again */
		if (ctx->state == BUF_HW_QUEUED)
			ctx->state = BUF_DRV_QUEUED;
		fthd_ctx_unmap(dev_priv, ctx);
	}
}

int fthd_v4l2_buffers_remap(struct fthd_private *dev_priv)
{
	struct h2t_buf_ctx *ctx;
	int i, ret;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		ctx = dev_priv->h2t_bufs + i;
		if (ctx->state == BUF_FREE || ctx->dma_desc_obj)
			continue;
		ret = fthd_ctx_map(dev_priv, ctx);
		if (ret)
			return ret;
	}
	return 0;
}

/* Give every buffer back to userspace and fail the queue. */
void fthd_v4l2_buffers_error(struct fthd_private *dev_priv)
{
	struct h2t_buf_ctx *ctx;
	int i;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		ctx = dev_priv->h2t_bufs + i;
		if (ctx->state != BUF_DRV_QUEUED && ctx->state != BUF_HW_QUEUED)
			continue;
		ctx->state = BUF_ALLOC;
		vb2_buffer_done(ctx->vb, VB2_BUF_STATE_ERROR);
	}
	vb2_queue_error(&dev_priv->vb2_queue);
}

static void fthd_return_drv_buffers(struct fthd_private *dev_priv,
				    enum vb2_buffer_state state)
{
	struct h2t_buf_ctx *ctx;
	int i;

	for (i = 0; i < FTHD_BUFFERS; i++) {
		ctx = dev_priv->h2t_bufs + i;
		if (ctx->state != BUF_DRV_QUEUED)
			continue;
		ctx->state = BUF_ALLOC;
		vb2_buffer_done(ctx->vb, state);
	}
}

static int fthd_start_streaming(struct vb2_queue *vq, unsigned int count)
{
	struct fthd_private *dev_priv = vb2_get_drv_priv(vq);
	int ret;

	pr_debug("count = %d\n", count);
	dev_priv->sequence = 0;
	cancel_delayed_work(&dev_priv->idle_work);

	/* remove tears the chip down and frees it; don't bring it up again */
	if (dev_priv->removing) {
		ret = -ENODEV;
		goto fail;
	}

	/* A failed recovery or suspend left the chip down; try once more */
	if (dev_priv->hw_state != FTHD_HW_UP) {
		ret = fthd_hw_restart(dev_priv, true);
		if (ret)
			goto fail;
	}

	ret = fthd_v4l2_stream_restart(dev_priv);
	if (ret && dev_priv->hw_state == FTHD_HW_FAILED) {
		/* The firmware hung while the camera was idle; restart it once */
		ret = fthd_hw_restart(dev_priv, true);
		if (!ret)
			ret = fthd_v4l2_stream_restart(dev_priv);
	}
	if (ret)
		goto fail;

	dev_priv->streaming = true;
	return 0;

fail:
	/* vb2 owns the buffers again if the queue never starts. */
	fthd_return_drv_buffers(dev_priv, VB2_BUF_STATE_QUEUED);
	fthd_schedule_idle(dev_priv);
	return ret;
}

static void fthd_stop_streaming(struct vb2_queue *vq)
{
	struct fthd_private *dev_priv = vb2_get_drv_priv(vq);
	int ret;

	dev_priv->streaming = false;
	fthd_frame_watchdog_stop(dev_priv);
	ret = fthd_stop_channel(dev_priv, 0);

	/* Buffers never sent to the firmware will not come back from it */
	fthd_return_drv_buffers(dev_priv, VB2_BUF_STATE_ERROR);

	/* After a channel stop the firmware returns what it holds */
	if (!ret && wait_event_timeout(vq->done_wq,
				       !atomic_read(&vq->owned_by_drv_count),
				       msecs_to_jiffies(FTHD_FRAME_TIMEOUT_MS))) {
		fthd_schedule_idle(dev_priv);
		return;
	}

	/*
	 * The firmware does not respond or keeps buffers. Cut its power before
	 * the buffers go back, so it cannot write into them any more.
	 */
	if (dev_priv->hw_state == FTHD_HW_UP)
		dev_err(&dev_priv->pdev->dev,
			"firmware did not return its buffers, stopping the chip\n");
	fthd_hw_halt(dev_priv);
	fthd_return_drv_buffers(dev_priv, VB2_BUF_STATE_ERROR);
}

static struct vb2_ops vb2_queue_ops = {
	.queue_setup            = fthd_buffer_queue_setup,
	.buf_prepare            = fthd_buffer_prepare,
	.buf_cleanup            = fthd_buffer_cleanup,
	.start_streaming        = fthd_start_streaming,
	.stop_streaming         = fthd_stop_streaming,
	.buf_queue              = fthd_buffer_queue,
#if LINUX_VERSION_CODE < KERNEL_VERSION(7, 0, 0)
	.wait_prepare           = vb2_ops_wait_prepare,
	.wait_finish            = vb2_ops_wait_finish,
#endif
};

static int fthd_v4l2_open(struct file *filp)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	int ret;

	ret = v4l2_fh_open(filp);
	if (!ret)
		atomic_inc(&dev_priv->users);

	return ret;
}

static int fthd_v4l2_release(struct file *filp)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	int ret;

	ret = vb2_fop_release(filp);
	atomic_dec(&dev_priv->users);

	return ret;
}

static struct v4l2_file_operations fthd_vdev_fops = {
	.owner          = THIS_MODULE,
	.open           = fthd_v4l2_open,

	.read		= vb2_fop_read,
	.release        = fthd_v4l2_release,
	.poll           = vb2_fop_poll,
	.mmap           = vb2_fop_mmap,
	.unlocked_ioctl = video_ioctl2
};

static int fthd_v4l2_ioctl_enum_input(struct file *filp, void *priv,
				      struct v4l2_input *input)
{
	if (input->index != 0)
		return -EINVAL;

	memset(input, 0, sizeof(*input));
	strcpy(input->name, "Camera");
	input->type = V4L2_INPUT_TYPE_CAMERA;
	input->std = 0;

	return 0;
}

static int fthd_v4l2_ioctl_g_input(struct file *filp, void *priv, unsigned int *i)
{
	*i = 0;
	return 0;
}

static int fthd_v4l2_ioctl_s_input(struct file *filp, void *priv, unsigned int i)
{
	if (i != 0)
		return -EINVAL;
	return 0;
}

static int fthd_v4l2_ioctl_querycap(struct file *filp, void *priv,
				    struct v4l2_capability *cap)
{
	struct fthd_private *dev_priv = video_drvdata(filp);

	strcpy(cap->driver, "facetimehd");
	strcpy(cap->card, "Apple Facetime HD");
	snprintf(cap->bus_info, sizeof(cap->bus_info), "PCI:%s",
		 pci_name(dev_priv->pdev));

	cap->device_caps = V4L2_CAP_VIDEO_CAPTURE | V4L2_CAP_READWRITE |
			   V4L2_CAP_STREAMING;
	cap->capabilities = cap->device_caps | V4L2_CAP_DEVICE_CAPS;
	return 0;
}

static int fthd_v4l2_ioctl_enum_fmt_vid_cap(struct file *filp, void *priv,
				   struct v4l2_fmtdesc *fmt)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,2,0)
	char *desc = NULL;
#endif

	switch (fmt->index) {
	case 0:
		fmt->pixelformat = V4L2_PIX_FMT_YUYV;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,2,0)
		desc = "YUYV";
#endif
		break;
	/* YVYU is not advertised: the ISP firmware's output for that format is
	 * broken (wrong/garbage chroma, renders green and pink). Apps that
	 * negotiate YVYU get a corrupted image; YUYV is correct. Requests for
	 * YVYU are coerced to YUYV in fthd_v4l2_adjust_format().
	 */
	/* We don't support the mplane yet
	case 2:
		fmt->pixelformat = V4L2_PIX_FMT_NV16;
		desc = "NV16";
		break;
	*/
	default:
		return -EINVAL;
	}

	fmt->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,2,0)
	strncpy(fmt->description, desc, sizeof(fmt->description));
#endif

	return 0;
}

static int fthd_v4l2_adjust_format(struct fthd_private *dev_priv,
				   struct v4l2_pix_format *pix)
{

	/* Upper bound is the sensor's native resolution (e.g. 1280x720 on
	 * MacBookPro, 848x588 on the 12-inch MacBook); fall back to the generic
	 * ceiling if it hasn't been detected yet. */
	unsigned int max_w = dev_priv->sensor_width  ? : FTHD_MAX_WIDTH;
	unsigned int max_h = dev_priv->sensor_height ? : FTHD_MAX_HEIGHT;

	if (pix->pixelformat != V4L2_PIX_FMT_YUYV)
		pix->pixelformat = V4L2_PIX_FMT_YUYV;

	if (pix->width < FTHD_MIN_WIDTH)
		pix->width = FTHD_MIN_WIDTH;
	if (pix->width > max_w)
		pix->width = max_w;
	if (pix->height < FTHD_MIN_HEIGHT)
		pix->height = FTHD_MIN_HEIGHT;
	if (pix->height > max_h)
		pix->height = max_h;

	pix->colorspace = V4L2_COLORSPACE_SRGB;
	pix->field = V4L2_FIELD_NONE;
	pix->width = ALIGN(pix->width, 8);

	switch (pix->pixelformat) {
/*
	case V4L2_PIX_FMT_NV16:
		pix->sizeimage = pix->width * pix->height;
		pix->bytesperline = pix->width;
		break;
*/
	case V4L2_PIX_FMT_YUYV:
	default:
		pix->bytesperline = pix->width * 2;
		pix->sizeimage = pix->bytesperline * pix->height;
		break;
	}

	return 0;
}

static int fthd_v4l2_ioctl_try_fmt_vid_cap(struct file *filp, void *_priv,
					   struct v4l2_format *fmt)
{
	struct fthd_private *dev_priv = video_drvdata(filp);

	pr_debug("%s: %dx%d\n", __FUNCTION__, fmt->fmt.pix.width, fmt->fmt.pix.height);

	if (fmt->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
		return -EINVAL;

	return fthd_v4l2_adjust_format(dev_priv, &fmt->fmt.pix);
}

static int fthd_v4l2_ioctl_g_fmt_vid_cap(struct file *filp, void *priv,
					 struct v4l2_format *fmt)
{
	struct fthd_private *dev_priv = video_drvdata(filp);

	pr_debug("%s\n", __FUNCTION__);
	fmt->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	fmt->fmt.pix = dev_priv->fmt.fmt;

	return 0;
}

static int fthd_v4l2_ioctl_s_fmt_vid_cap(struct file *filp, void *priv,
					 struct v4l2_format *fmt)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	int ret;

	if (fmt->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
		return -EINVAL;

	ret = fthd_v4l2_adjust_format(dev_priv, &fmt->fmt.pix);
	if (ret)
		return ret;

	ret = mutex_lock_interruptible(&dev_priv->vb2_queue_lock);
	if (ret)
		return ret;
	/*
	 * The buffers are sized for the current format, and a stream
	 * restart (recovery, resume) programs the firmware with it again.
	 */
	if (vb2_is_busy(&dev_priv->vb2_queue)) {
		mutex_unlock(&dev_priv->vb2_queue_lock);
		return -EBUSY;
	}

	pr_debug("%c%c%c%c\n", fmt->fmt.pix.pixelformat, fmt->fmt.pix.pixelformat >> 8,
		 fmt->fmt.pix.pixelformat >> 16, fmt->fmt.pix.pixelformat >> 24);

	dev_priv->fmt.fmt = fmt->fmt.pix;

	switch (fmt->fmt.pix.pixelformat) {
	case V4L2_PIX_FMT_NV16:
		dev_priv->fmt.planes = 2;
		break;
	case V4L2_PIX_FMT_YUYV:
		dev_priv->fmt.planes = 1;
		break;
	}
	mutex_unlock(&dev_priv->vb2_queue_lock);

	return 0;
}


static int fthd_v4l2_ioctl_g_parm(struct file *filp, void *priv,
		struct v4l2_streamparm *parm)
{
	struct fthd_private *dev_priv = video_drvdata(filp);

	if (parm->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
		return -EINVAL;

	parm->parm.capture.readbuffers = FTHD_BUFFERS;
	parm->parm.capture.capability = V4L2_CAP_TIMEPERFRAME;
	parm->parm.capture.timeperframe.numerator = FTHD_FRAME_RATE_SCALE;
	parm->parm.capture.timeperframe.denominator = READ_ONCE(dev_priv->frame_rate);
	return 0;
}

static int fthd_v4l2_ioctl_s_parm(struct file *filp, void *priv,
		struct v4l2_streamparm *parm)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	struct v4l2_fract *tpf = &parm->parm.capture.timeperframe;
	u64 rate = FTHD_FRAME_RATE_MAX;
	int ret;

	if (parm->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
		return -EINVAL;
	if (tpf->numerator && tpf->denominator)
		rate = div_u64((u64)tpf->denominator * FTHD_FRAME_RATE_SCALE,
			       tpf->numerator);
	rate = clamp_t(u64, rate, FTHD_FRAME_RATE_MIN, FTHD_FRAME_RATE_MAX);

	ret = mutex_lock_interruptible(&dev_priv->vb2_queue_lock);
	if (ret)
		return ret;
	/* Rate commands take effect at channel start. Do not promise a live change. */
	if (vb2_is_streaming(&dev_priv->vb2_queue)) {
		ret = -EBUSY;
	} else {
		WRITE_ONCE(dev_priv->frame_rate, (u32)rate);
		ret = fthd_v4l2_ioctl_g_parm(filp, priv, parm);
	}
	mutex_unlock(&dev_priv->vb2_queue_lock);
	return ret;
}

/* Report the sensor area the scaler reads from. V4L2_SEL_TGT_CROP is left
 * out: the window in use depends on the negotiated format.
 */
static int fthd_v4l2_ioctl_g_selection(struct file *filp, void *priv,
		struct v4l2_selection *sel)
{
	struct fthd_private *dev_priv = video_drvdata(filp);

	if (sel->type != V4L2_BUF_TYPE_VIDEO_CAPTURE)
		return -EINVAL;

	switch (sel->target) {
	case V4L2_SEL_TGT_CROP_DEFAULT:
	case V4L2_SEL_TGT_CROP_BOUNDS:
		break;
	default:
		return -EINVAL;
	}

	sel->r.left = 0;
	sel->r.top = 0;
	sel->r.width = dev_priv->sensor_width ? : FTHD_MAX_WIDTH;
	sel->r.height = dev_priv->sensor_height ? : FTHD_MAX_HEIGHT;

	return 0;
}

/* Frame sizes reported to userspace, smallest first. Chromium skips stepwise
 * frame sizes, both in its V4L2 capture and in libwebrtc's PipeWire camera,
 * and then drops the camera altogether, so the sizes are listed one by one.
 * The ISP crops centred to the requested aspect ratio and scales, so these
 * common 4:3 and 16:9 sizes are not distorted. Sizes above the sensor are
 * left out; the sensor's native size always comes last. */
static const struct {
	unsigned int width, height;
} fthd_frame_sizes[] = {
	{ 320, 240 }, { 424, 240 }, { 640, 360 }, { 640, 480 }, { 848, 480 },
	{ 1280, 720 },
};

static int fthd_v4l2_ioctl_enum_framesizes(struct file *filp, void *priv,
		struct v4l2_frmsizeenum *sizes)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	unsigned int max_w = (dev_priv->sensor_width ? : FTHD_MAX_WIDTH) & ~7u;
	unsigned int max_h = dev_priv->sensor_height ? : FTHD_MAX_HEIGHT;
	unsigned int i, n = 0;

	if (sizes->pixel_format != V4L2_PIX_FMT_YUYV)
		return -EINVAL;

	sizes->type = V4L2_FRMSIZE_TYPE_DISCRETE;
	for (i = 0; i < ARRAY_SIZE(fthd_frame_sizes); i++) {
		unsigned int w = fthd_frame_sizes[i].width;
		unsigned int h = fthd_frame_sizes[i].height;

		if (w > max_w || h > max_h || (w == max_w && h == max_h))
			continue;
		if (n++ == sizes->index) {
			sizes->discrete.width = w;
			sizes->discrete.height = h;
			return 0;
		}
	}

	if (sizes->index != n)
		return -EINVAL;
	sizes->discrete.width = max_w;
	sizes->discrete.height = max_h;

	return 0;
}

static int fthd_v4l2_ioctl_enum_frameintervals(struct file *filp, void *priv,
		struct v4l2_frmivalenum *interval)
{
	struct fthd_private *dev_priv = video_drvdata(filp);
	unsigned int max_w = dev_priv->sensor_width  ? : FTHD_MAX_WIDTH;
	unsigned int max_h = dev_priv->sensor_height ? : FTHD_MAX_HEIGHT;

	pr_debug("%s\n", __FUNCTION__);

	if (interval->index)
		return -EINVAL;

	if (interval->pixel_format != V4L2_PIX_FMT_YUYV &&
	    interval->pixel_format != V4L2_PIX_FMT_NV16)
		return -EINVAL;

	if (interval->width & 7
	    || interval->width > max_w
	    || interval->height > max_h)
		return -EINVAL;

	interval->type = V4L2_FRMIVAL_TYPE_DISCRETE;
	interval->discrete.numerator = 1;
	interval->discrete.denominator = 30;

	return 0;
}

static int fthd_v4l2_ioctl_subscribe_event(struct v4l2_fh *fh,
		const struct v4l2_event_subscription *sub)
{
	switch (sub->type) {
	case V4L2_EVENT_CTRL:
		return v4l2_ctrl_subscribe_event(fh, sub);
	}

	return -EINVAL;
}

static struct v4l2_ioctl_ops fthd_ioctl_ops = {
	.vidioc_enum_input      = fthd_v4l2_ioctl_enum_input,
	.vidioc_g_input         = fthd_v4l2_ioctl_g_input,
	.vidioc_s_input         = fthd_v4l2_ioctl_s_input,
	.vidioc_enum_fmt_vid_cap = fthd_v4l2_ioctl_enum_fmt_vid_cap,
	.vidioc_try_fmt_vid_cap = fthd_v4l2_ioctl_try_fmt_vid_cap,

	.vidioc_g_fmt_vid_cap   = fthd_v4l2_ioctl_g_fmt_vid_cap,
	.vidioc_s_fmt_vid_cap   = fthd_v4l2_ioctl_s_fmt_vid_cap,
	.vidioc_querycap        = fthd_v4l2_ioctl_querycap,


        .vidioc_reqbufs         = vb2_ioctl_reqbufs,
	.vidioc_create_bufs     = vb2_ioctl_create_bufs,
	.vidioc_querybuf        = vb2_ioctl_querybuf,
	.vidioc_qbuf            = vb2_ioctl_qbuf,
	.vidioc_dqbuf           = vb2_ioctl_dqbuf,
	.vidioc_expbuf          = vb2_ioctl_expbuf,
	.vidioc_streamon        = vb2_ioctl_streamon,
	.vidioc_streamoff       = vb2_ioctl_streamoff,

	.vidioc_g_parm          = fthd_v4l2_ioctl_g_parm,
	.vidioc_s_parm          = fthd_v4l2_ioctl_s_parm,
	.vidioc_g_selection     = fthd_v4l2_ioctl_g_selection,
	.vidioc_enum_framesizes = fthd_v4l2_ioctl_enum_framesizes,
	.vidioc_enum_frameintervals = fthd_v4l2_ioctl_enum_frameintervals,

	.vidioc_subscribe_event	= fthd_v4l2_ioctl_subscribe_event,
	.vidioc_unsubscribe_event = v4l2_event_unsubscribe,
};

static int fthd_g_volatile_ctrl(struct v4l2_ctrl *ctrl)
{
	pr_debug("id = %x\n", ctrl->id);
	return -EINVAL;
}

static int fthd_s_ctrl(struct v4l2_ctrl *ctrl)
{
	struct fthd_private *dev_priv = container_of(ctrl->handler, struct fthd_private, v4l2_ctrl_handler);
	int ret = -EINVAL;

	pr_debug("id = %x, val = %d\n", ctrl->id, ctrl->val);

	/* Stored values are sent to the firmware when the channel starts */
	if (dev_priv->hw_state != FTHD_HW_UP)
		return 0;

	switch(ctrl->id) {
	case V4L2_CID_CONTRAST:
		ret = fthd_isp_cmd_channel_contrast_set(dev_priv, 0, ctrl->val);
		break;
	case V4L2_CID_BRIGHTNESS:
		ret = fthd_isp_cmd_channel_brightness_set(dev_priv, 0, ctrl->val);
		break;
	case V4L2_CID_SATURATION:
		ret = fthd_isp_cmd_channel_saturation_set(dev_priv, 0, ctrl->val);
		break;
	case V4L2_CID_HUE:
		ret = fthd_isp_cmd_channel_hue_set(dev_priv, 0, ctrl->val);
		break;
	case V4L2_CID_AUTO_WHITE_BALANCE:
		ret = fthd_isp_cmd_channel_awb(dev_priv, 0, ctrl->val);
		break;
	case V4L2_CID_EXPOSURE_AUTO:
		/* The firmware runs auto exposure unconditionally. */
		ret = 0;
		break;
	case V4L2_CID_EXPOSURE_AUTO_PRIORITY:
		ret = fthd_isp_cmd_channel_frame_rate_min(dev_priv, 0,
							  fthd_isp_ae_frame_rate_min(dev_priv, ctrl->val));
		if (!ret)
			dev_priv->exposure_auto_priority = ctrl->val;
		break;
	default:
		break;

	}
	pr_debug("ret = %d\n", ret);
	return ret;
}

static const struct v4l2_ctrl_ops fthd_ctrl_ops = {
	.g_volatile_ctrl = fthd_g_volatile_ctrl,
	.s_ctrl = fthd_s_ctrl,
};

int fthd_v4l2_register(struct fthd_private *dev_priv)
{
	struct v4l2_device *v4l2_dev = &dev_priv->v4l2_dev;
	struct video_device *vdev;
	struct vb2_queue *q;
	int ret;

	ret = v4l2_device_register(&dev_priv->pdev->dev, v4l2_dev);
	if (ret) {
		pr_err("v4l2_device_register: %d\n", ret);
		return ret;
	}

	vdev = video_device_alloc();
	if (!vdev) {
		ret = -ENOMEM;
		goto fail;
	}
	dev_priv->videodev = vdev;

	q = &dev_priv->vb2_queue;
	q->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	q->io_modes = VB2_MMAP | VB2_USERPTR | VB2_DMABUF | VB2_READ;
	q->drv_priv = dev_priv;
	q->ops = &vb2_queue_ops;
	q->mem_ops = &vb2_dma_sg_memops;
	q->buf_struct_size = 0;//sizeof(struct vpif_cap_buffer);
	q->timestamp_flags = V4L2_BUF_FLAG_TIMESTAMP_MONOTONIC;
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,8,0)
	q->min_buffers_needed = 1;
#else
	q->min_queued_buffers = 1;
#endif
	q->lock = &dev_priv->vb2_queue_lock;

	ret = vb2_queue_init(q);
	if (ret)
		goto fail;

	v4l2_ctrl_handler_init(&dev_priv->v4l2_ctrl_handler, 7);
	/* Controls talk to the firmware, which recovery may restart */
	dev_priv->v4l2_ctrl_handler.lock = &dev_priv->vb2_queue_lock;
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_BRIGHTNESS, 0, 0xff, 1, 0x80);
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_CONTRAST, 0, 0xff, 1, 0x80);
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_SATURATION, 0, 0xff, 1, 0x80);
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_HUE, 0, 0xff, 1, 0x80);
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_AUTO_WHITE_BALANCE, 0, 1, 1, 1);
	v4l2_ctrl_new_std_menu(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			       V4L2_CID_EXPOSURE_AUTO,
			       V4L2_EXPOSURE_APERTURE_PRIORITY,
			       ~(1 << V4L2_EXPOSURE_AUTO), V4L2_EXPOSURE_AUTO);
	v4l2_ctrl_new_std(&dev_priv->v4l2_ctrl_handler, &fthd_ctrl_ops,
			  V4L2_CID_EXPOSURE_AUTO_PRIORITY, 0, 1, 1, 0);

	if (dev_priv->v4l2_ctrl_handler.error) {
		pr_err("failed to setup control handlers\n");
		v4l2_ctrl_handler_free(&dev_priv->v4l2_ctrl_handler);
		goto fail;
	}
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
	dev_priv->alloc_ctx = vb2_dma_sg_init_ctx(&dev_priv->pdev->dev);
#endif
	vdev->v4l2_dev = v4l2_dev;
	strcpy(vdev->name, "Apple Facetime HD"); // XXX: Length?
	vdev->vfl_dir = VFL_DIR_RX;
	vdev->fops = &fthd_vdev_fops;
	vdev->ioctl_ops = &fthd_ioctl_ops;
	vdev->queue = q;
	vdev->release = video_device_release;
	vdev->ctrl_handler = &dev_priv->v4l2_ctrl_handler;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5,4,0)
	vdev->device_caps = V4L2_CAP_VIDEO_CAPTURE | V4L2_CAP_READWRITE |
			    V4L2_CAP_STREAMING;
#endif
	video_set_drvdata(vdev, dev_priv);
	ret = video_register_device(vdev, VFL_TYPE_VIDEO, -1);
	if (ret) {
		video_device_release(vdev);
		goto fail_vdev;
	}
	/* Default to the sensor's native resolution (detected at probe), or the
	 * generic ceiling if detection didn't run. */
	dev_priv->fmt.fmt.width  = dev_priv->sensor_width  ? : FTHD_MAX_WIDTH;
	dev_priv->fmt.fmt.height = dev_priv->sensor_height ? : FTHD_MAX_HEIGHT;
	dev_priv->fmt.fmt.pixelformat = V4L2_PIX_FMT_YUYV;
	dev_priv->fmt.fmt.sizeimage = dev_priv->fmt.fmt.width * dev_priv->fmt.fmt.height * 2;
	dev_priv->fmt.planes = 1;

	fthd_v4l2_adjust_format(dev_priv, &dev_priv->fmt.fmt);

	return 0;
fail_vdev:
	v4l2_ctrl_handler_free(&dev_priv->v4l2_ctrl_handler);
fail:
	v4l2_device_unregister(&dev_priv->v4l2_dev);
	return ret;
}

void fthd_v4l2_unregister(struct fthd_private *dev_priv)
{

	v4l2_ctrl_handler_free(&dev_priv->v4l2_ctrl_handler);
#if LINUX_VERSION_CODE < KERNEL_VERSION(4,8,0)
	vb2_dma_sg_cleanup_ctx(dev_priv->alloc_ctx);
#endif
	video_unregister_device(dev_priv->videodev);
	v4l2_device_unregister(&dev_priv->v4l2_dev);
}

/*
 * SPDX-License-Identifier: GPL-2.0-only
 *
 * FacetimeHD camera driver
 *
 * Copyright (C) 2014 Patrik Jakobsson (patrik.r.jakobsson@gmail.com)
 *
 */

#include <linux/delay.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,4,0)
#include <linux/pci-aspm.h>
#endif
#include <linux/io.h>
#include <linux/interrupt.h>
#include <linux/workqueue.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/wait.h>
#include <linux/suspend.h>
#include <linux/videodev2.h>
#include "fthd_drv.h"
#include "fthd_hw.h"
#include "fthd_isp.h"
#include "fthd_ringbuf.h"
#include "fthd_buffer.h"
#include "fthd_v4l2.h"
#include "fthd_debugfs.h"

static int fthd_pci_reserve_mem(struct fthd_private *dev_priv)
{
	unsigned long start;
	unsigned long len;
	int ret;

	/* Reserve resources */
	ret = pci_request_region(dev_priv->pdev, FTHD_PCI_S2_IO, "S2 IO");
	if (ret) {
		dev_err(&dev_priv->pdev->dev, "Failed to request S2 IO\n");
		return ret;
	}

	ret = pci_request_region(dev_priv->pdev, FTHD_PCI_ISP_IO, "ISP IO");
	if (ret) {
		dev_err(&dev_priv->pdev->dev, "Failed to request ISP IO\n");
		pci_release_region(dev_priv->pdev, FTHD_PCI_S2_IO);
		return ret;
	}

	ret = pci_request_region(dev_priv->pdev, FTHD_PCI_S2_MEM, "S2 MEM");
	if (ret) {
		pci_release_region(dev_priv->pdev, FTHD_PCI_ISP_IO);
		pci_release_region(dev_priv->pdev, FTHD_PCI_S2_IO);
		return ret;
	}

	/* S2 IO */
	start = pci_resource_start(dev_priv->pdev, FTHD_PCI_S2_IO);
	len = pci_resource_len(dev_priv->pdev, FTHD_PCI_S2_IO);
	dev_priv->s2_io = ioremap(start, len);
	dev_priv->s2_io_len = len;

	/* S2 MEM */
	start = pci_resource_start(dev_priv->pdev, FTHD_PCI_S2_MEM);
	len = pci_resource_len(dev_priv->pdev, FTHD_PCI_S2_MEM);
	dev_priv->s2_mem = ioremap(start, len);
	dev_priv->s2_mem_len = len;

	/* ISP IO */
	start = pci_resource_start(dev_priv->pdev, FTHD_PCI_ISP_IO);
	len = pci_resource_len(dev_priv->pdev, FTHD_PCI_ISP_IO);
	dev_priv->isp_io = ioremap(start, len);
	dev_priv->isp_io_len = len;

	pr_debug("Allocated S2 regs (BAR %d). %u bytes at 0x%p\n",
		 FTHD_PCI_S2_IO, dev_priv->s2_io_len, dev_priv->s2_io);

	pr_debug("Allocated S2 mem (BAR %d). %u bytes at 0x%p\n",
		 FTHD_PCI_S2_MEM, dev_priv->s2_mem_len, dev_priv->s2_mem);

	pr_debug("Allocated ISP regs (BAR %d). %u bytes at 0x%p\n",
		 FTHD_PCI_ISP_IO, dev_priv->isp_io_len, dev_priv->isp_io);

	return 0;
}

static void sharedmalloc_handler(struct fthd_private *dev_priv,
				 struct fw_channel *chan,
				 u32 entry)
{
	u32 request_size, response_size, address;
	struct isp_mem_obj *obj;
	int ret;

	request_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_REQUEST_SIZE);
	response_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_RESPONSE_SIZE);
	address = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_ADDRESS_FLAGS) & ~ 3;

	if (address) {
		pr_debug("Firmware wants to free memory at %08x\n", address);
		FTHD_S2_MEMCPY_FROMIO(&obj, address - 64, sizeof(obj));
		isp_mem_destroy(obj);

		ret = fthd_channel_ringbuf_send(dev_priv, chan, 0, 0, 0, NULL);
		if (ret)
			pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);
	} else {
		if (!request_size)
			return;
		obj = isp_mem_create(dev_priv, FTHD_MEM_SHAREDMALLOC, request_size + 64);
		if (!obj)
			return;

		pr_debug("Firmware allocated %d bytes at %08lx (tag %c%c%c%c)\n", request_size, obj->offset,
			 response_size >> 24,response_size >> 16,
			 response_size >> 8, response_size);
		FTHD_S2_MEMCPY_TOIO(obj->offset, &obj, sizeof(obj));
		ret = fthd_channel_ringbuf_send(dev_priv, chan, obj->offset + 64, 0, 0, NULL);
		if (ret)
			pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);

	}

}


static void terminal_handler(struct fthd_private *dev_priv,
				 struct fw_channel *chan,
				 u32 entry)
{
	u32 request_size, response_size, address;
	char buf[512];

	request_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_REQUEST_SIZE);
	response_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_RESPONSE_SIZE);
	address = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_ADDRESS_FLAGS) & ~ 3;

	if (!address || !request_size)
		return;

	if (request_size > 512)
		request_size = 512;
	FTHD_S2_MEMCPY_FROMIO(buf, address, request_size);
	pr_info("FWMSG: %.*s", request_size, buf);
}

static void buf_t2h_handler(struct fthd_private *dev_priv,
			    struct fw_channel *chan,
			    u32 entry)
{
	u32 request_size, response_size, address;
	int ret;
	request_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_REQUEST_SIZE);
	response_size = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_RESPONSE_SIZE);
	address = FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_ADDRESS_FLAGS);

	if (address & 1)
		return;


	fthd_buffer_return_handler(dev_priv, address & ~3, request_size);
	ret = fthd_channel_ringbuf_send(dev_priv, chan, (response_size & 0x10000000) ? address : 0,
					0, 0x80000000, NULL);
	if (ret)
		pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);

}

static void io_t2h_handler(struct fthd_private *dev_priv,
				 struct fw_channel *chan,
				 u32 entry)
{
	int ret = fthd_channel_ringbuf_send(dev_priv, chan, 0, 0, 0, NULL);
	if (ret)
		pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);

}

static void fthd_handle_irq(struct fthd_private *dev_priv, struct fw_channel *chan)
{
	u32 entry;
	int ret;

	if (chan == dev_priv->channel_io) {
		pr_debug("IO channel ready\n");
		wake_up(&chan->wq);
		return;
	}

	if (chan == dev_priv->channel_buf_h2t) {
		pr_debug("H2T channel ready\n");
		wake_up(&chan->wq);
		return;
	}

	if (chan == dev_priv->channel_debug) {
		pr_debug("DEBUG channel ready\n");
		wake_up(&chan->wq);
		return;
	}

	while((entry = fthd_channel_ringbuf_receive(dev_priv, chan)) != (u32)-1) {
		pr_debug("channel %s: message available, address %08x\n", chan->name, FTHD_S2_MEM_READ(entry + FTHD_RINGBUF_ADDRESS_FLAGS));
		if (chan == dev_priv->channel_shared_malloc) {
			sharedmalloc_handler(dev_priv, chan, entry);
		} else if (chan == dev_priv->channel_terminal) {
			terminal_handler(dev_priv, chan, entry);
			ret = fthd_channel_ringbuf_send(dev_priv, chan, 0, 0, 0, NULL);
			if (ret)
				pr_err("%s: fthd_channel_ringbuf_send: %d\n", __FUNCTION__, ret);
		} else if (chan == dev_priv->channel_buf_t2h) {
			buf_t2h_handler(dev_priv, chan, entry);
		} else if (chan == dev_priv->channel_io_t2h) {
			io_t2h_handler(dev_priv, chan, entry);
		}
	}
}

static void fthd_irq_uninstall(struct fthd_private *dev_priv)
{
	free_irq(dev_priv->pdev->irq, dev_priv);
}

static void fthd_irq_work(struct work_struct *work)
{
	struct fthd_private *dev_priv = container_of(work, struct fthd_private, irq_work);
	struct fw_channel *chan;

	u32 pending;
	int i = 0, loops = 0;

	if (READ_ONCE(dev_priv->hw_state) == FTHD_HW_DOWN)
		return;

	while(loops++ < 500) {
		spin_lock_irq(&dev_priv->io_lock);
		pending = FTHD_ISP_REG_READ(ISP_IRQ_STATUS);
		spin_unlock_irq(&dev_priv->io_lock);

		if (!(pending & 0xf0))
			break;

		pci_write_config_dword(dev_priv->pdev, 0x94, 0);
		spin_lock_irq(&dev_priv->io_lock);
		FTHD_ISP_REG_WRITE(pending, ISP_IRQ_CLEAR);
		spin_unlock_irq(&dev_priv->io_lock);
		pci_write_config_dword(dev_priv->pdev, 0x90, 0x200);

		for(i = 0; i < dev_priv->num_channels; i++) {
			chan = dev_priv->channels[i];


			BUG_ON(chan->source > 3);
			if (!((0x10 << chan->source) & pending))
				continue;
			fthd_handle_irq(dev_priv, chan);
		}
	}

	if (loops >= 500) {
		/* Leave the interrupt gate closed; recovery reopens it */
		dev_err(&dev_priv->pdev->dev, "irq stuck, disabling\n");
		fthd_irq_disable(dev_priv);
		fthd_hw_hung(dev_priv, "interrupt");
		return;
	}
	pci_write_config_dword(dev_priv->pdev, 0x94, 0x200);
}

static irqreturn_t fthd_irq_handler(int irq, void *arg)
{
	struct fthd_private *dev_priv = arg;
	u32 pending;
	unsigned long flags;

	if (READ_ONCE(dev_priv->hw_state) == FTHD_HW_DOWN)
		return IRQ_NONE;

	spin_lock_irqsave(&dev_priv->io_lock, flags);
	pending = FTHD_ISP_REG_READ(ISP_IRQ_STATUS);
	spin_unlock_irqrestore(&dev_priv->io_lock, flags);

	if (!(pending & 0xf0))
		return IRQ_NONE;

	schedule_work(&dev_priv->irq_work);

	return IRQ_HANDLED;
}

static int fthd_irq_install(struct fthd_private *dev_priv)
{
	int ret;

	ret = request_irq(dev_priv->pdev->irq, fthd_irq_handler, IRQF_SHARED,
			  KBUILD_MODNAME, (void *)dev_priv);

	if (ret)
		dev_err(&dev_priv->pdev->dev, "Failed to request IRQ\n");

	return ret;
}

static int fthd_pci_set_dma_mask(struct fthd_private *dev_priv,
				 unsigned int mask)
{
	int ret;

	ret = dma_set_mask_and_coherent(&dev_priv->pdev->dev, DMA_BIT_MASK(mask));
	if (ret) {
		dev_err(&dev_priv->pdev->dev, "Failed to set %u pci dma mask\n",
			mask);
		return ret;
	}

	dev_priv->dma_mask = mask;

	return 0;
}

static void fthd_stop_firmware(struct fthd_private *dev_priv)
{
	fthd_isp_cmd_stop(dev_priv);
	isp_powerdown(dev_priv);
}

static void fthd_pci_unmap(struct fthd_private *dev_priv)
{
	struct pci_dev *pdev = dev_priv->pdev;

	if (dev_priv->s2_io)
		iounmap(dev_priv->s2_io);
	if (dev_priv->s2_mem)
		iounmap(dev_priv->s2_mem);
	if (dev_priv->isp_io)
		iounmap(dev_priv->isp_io);

	pci_release_region(pdev, FTHD_PCI_S2_IO);
	pci_release_region(pdev, FTHD_PCI_S2_MEM);
	pci_release_region(pdev, FTHD_PCI_ISP_IO);
}

static int fthd_firmware_start(struct fthd_private *dev_priv)
{
	int ret;

	ret = fthd_isp_cmd_start(dev_priv);
	if (ret)
		return ret;

	ret = fthd_isp_cmd_print_enable(dev_priv, 1);
	if (ret)
		return ret;

	ret = fthd_isp_cmd_camera_config(dev_priv);
	if (ret)
		return ret;

	ret = fthd_isp_cmd_channel_info(dev_priv);
	if (ret)
		return ret;

	/* Query the sensor's native resolution now so fthd_v4l2_register()
	 * can advertise it. Non-fatal: if it fails the V4L2 layer falls back
	 * to a default size. */
	fthd_isp_cmd_channel_camera_config(dev_priv);

	return fthd_isp_cmd_set_loadfile(dev_priv);

}

/* Stop interrupt delivery and wait for handlers that are still running. */
static void fthd_hw_quiesce(struct fthd_private *dev_priv)
{
	fthd_irq_disable(dev_priv);
	synchronize_irq(dev_priv->pdev->irq);
	cancel_work_sync(&dev_priv->irq_work);
	/* A finishing irq work reopens the interrupt gate */
	fthd_irq_disable(dev_priv);
}

/*
 * Bring the S2 chip from reset to a running ISP firmware. Everything set up
 * here lives in S2 memory and is lost when the chip loses power.
 */
static int fthd_hw_bringup(struct fthd_private *dev_priv)
{
	int ret;

	dev_priv->hw_state = FTHD_HW_STARTING;

	ret = fthd_buffer_init(dev_priv);
	if (ret)
		goto fail;

	ret = fthd_hw_init(dev_priv);
	if (ret)
		goto fail_buffer;

	ret = fthd_firmware_start(dev_priv);
	if (ret)
		goto fail_isp;

	dev_priv->hw_state = FTHD_HW_UP;
	return 0;

fail_isp:
	dev_priv->hw_state = FTHD_HW_DOWN;
	fthd_hw_quiesce(dev_priv);
	isp_uninit(dev_priv);
	fthd_hw_deinit(dev_priv);
fail_buffer:
	fthd_buffer_exit(dev_priv);
fail:
	dev_priv->hw_state = FTHD_HW_DOWN;
	return ret;
}

/*
 * Undo fthd_hw_bringup(). The firmware is only asked to stop when it is
 * known to respond; a hung ISP CPU is halted by isp_uninit() instead.
 * Queued buffers stay with the driver and are mapped again on bring-up.
 */
static void fthd_hw_teardown(struct fthd_private *dev_priv)
{
	if (dev_priv->hw_state == FTHD_HW_DOWN)
		return;

	if (dev_priv->hw_state == FTHD_HW_UP)
		fthd_stop_firmware(dev_priv);

	dev_priv->hw_state = FTHD_HW_DOWN;
	fthd_hw_quiesce(dev_priv);
	/* Only now: the irq work re-arms it for every buffer it returns */
	fthd_frame_watchdog_stop(dev_priv);
	/* Descriptors and IOMMU entries live in S2 memory */
	fthd_v4l2_buffers_unmap(dev_priv);
	isp_uninit(dev_priv);
	fthd_hw_deinit(dev_priv);
	fthd_buffer_exit(dev_priv);
}

/*
 * While the chip has power the driver keeps ASPM off on its link, which
 * holds the CPU package in PC3; without power the link is down and the
 * package may go deeper.
 */
static int idle_poweroff_ms = 5000;
module_param(idle_poweroff_ms, int, 0644);
MODULE_PARM_DESC(idle_poweroff_ms,
		 "Power the camera off after this many ms without a stream (-1: never)");

/* Camera power timing of the macOS driver (DisableS2Chip, EnableS2Chip) */
#define FTHD_POWER_OFF_MS	250
#define FTHD_POWER_ON_MS	20

/* Cut the camera power through the ACPI CMPE method. */
static void fthd_power_off(struct fthd_private *dev_priv)
{
	pci_clear_master(dev_priv->pdev);
	if (isp_acpi_set_power(dev_priv, 0))
		dev_warn(&dev_priv->pdev->dev, "failed to power the camera off\n");
	/* Boot time keeps counting while the system sleeps */
	dev_priv->power_off_time = ktime_get_boottime();
	dev_priv->powered_off = true;
}

/* Power the camera on again; its config space still has to be restored. */
static int fthd_power_on(struct fthd_private *dev_priv)
{
	s64 off_ms = ktime_ms_delta(ktime_get_boottime(), dev_priv->power_off_time);
	int ret;

	if (off_ms < FTHD_POWER_OFF_MS)
		msleep(FTHD_POWER_OFF_MS - off_ms);

	ret = isp_acpi_set_power(dev_priv, 1);
	dev_priv->powered_off = false;
	dev_priv->last_off_ms = ktime_ms_delta(ktime_get_boottime(),
					       dev_priv->power_off_time);
	dev_priv->power_cycles++;
	if (ret)
		return ret;

	msleep(FTHD_POWER_ON_MS);
	return 0;
}

/*
 * Power cycling is the only reset that also restarts a hung ISP CPU; the
 * macOS driver recovers the same way.
 */
static int fthd_power_cycle(struct fthd_private *dev_priv)
{
	struct pci_dev *pdev = dev_priv->pdev;
	u32 id;
	int ret;

	if (!dev_priv->powered_off)
		fthd_power_off(dev_priv);

	ret = fthd_power_on(dev_priv);
	if (ret)
		return ret;

	/* The config space went with the power; restore the copy from probe */
	pci_load_saved_state(pdev, dev_priv->pci_state);
	pci_restore_state(pdev);

	pci_read_config_dword(pdev, PCI_VENDOR_ID, &id);
	if (id != (PCI_VENDOR_ID_BROADCOM | (pdev->device << 16))) {
		dev_err(&pdev->dev,
			"camera did not return after power cycle (id %08x)\n", id);
		return -ENODEV;
	}

	/* PME_En comes up undefined; the PCI core keeps it off in D0 */
	pci_pme_active(pdev, false);
	return 0;
}

/* Take the chip down and cut its power. Called with vb2_queue_lock held. */
static void fthd_hw_power_down(struct fthd_private *dev_priv)
{
	fthd_hw_teardown(dev_priv);
	if (!dev_priv->powered_off)
		fthd_power_off(dev_priv);
}

/*
 * Give a powered off chip its power and config space back, so that system
 * sleep and a later probe find it as the PCI core left it.
 */
static void fthd_power_restore(struct fthd_private *dev_priv)
{
	if (dev_priv->powered_off && fthd_power_cycle(dev_priv))
		dev_err(&dev_priv->pdev->dev, "failed to power the camera on\n");
}

/*
 * Restart the camera hardware and resume a running stream. Called with
 * vb2_queue_lock held.
 */
int fthd_hw_restart(struct fthd_private *dev_priv, bool power_cycle)
{
	int ret;

	fthd_hw_teardown(dev_priv);

	if (power_cycle) {
		ret = fthd_power_cycle(dev_priv);
		if (ret)
			goto fail;
	}

	ret = fthd_hw_bringup(dev_priv);
	if (ret)
		goto fail;

	ret = fthd_v4l2_buffers_remap(dev_priv);
	if (ret)
		goto fail_hw;

	if (dev_priv->streaming) {
		ret = fthd_v4l2_stream_restart(dev_priv);
		if (ret)
			goto fail_hw;
	}
	return 0;

fail_hw:
	/* The firmware did not take the stream; don't ask it to stop */
	dev_priv->hw_state = FTHD_HW_FAILED;
	fthd_hw_teardown(dev_priv);
fail:
	/* The chip is down now; streaming or recovery may try again */
	return ret;
}

static void fthd_recover_work(struct work_struct *work)
{
	struct fthd_private *dev_priv =
		container_of(work, struct fthd_private, recover_work);
	bool resuming, power_cycle;
	int attempt, ret = -EIO;

	mutex_lock(&dev_priv->vb2_queue_lock);

	resuming = dev_priv->resuming;
	dev_priv->resuming = false;
	/* Fresh from power-on in resume, the chip needs no further reset */
	power_cycle = !dev_priv->fresh_power;
	dev_priv->fresh_power = false;

	/* Resume brings the hardware up anyway, remove tears it down */
	if (dev_priv->suspended || dev_priv->removing)
		goto out;

	/* Without a stream the chip only needs power again for the next one */
	if (!dev_priv->streaming && !dev_priv->force_recover &&
	    READ_ONCE(idle_poweroff_ms) >= 0) {
		fthd_hw_power_down(dev_priv);
		goto out;
	}

	/* A stream start may have restarted the chip already */
	if (dev_priv->hw_state == FTHD_HW_UP && !dev_priv->force_recover)
		goto out;
	dev_priv->force_recover = false;

	for (attempt = 1; attempt <= FTHD_RECOVER_ATTEMPTS; attempt++) {
		if (!resuming || attempt > 1)
			dev_warn(&dev_priv->pdev->dev,
				 "restarting camera with power cycle (attempt %d of %d)\n",
				 attempt, FTHD_RECOVER_ATTEMPTS);
		ret = fthd_hw_restart(dev_priv, power_cycle);
		if (!ret)
			break;
		power_cycle = true;
		msleep(500 * attempt);
	}

	if (!resuming)
		dev_priv->recover_count++;
	if (ret) {
		dev_err(&dev_priv->pdev->dev,
			"camera restart failed (%d); restarting the stream retries\n",
			ret);
		fthd_v4l2_buffers_error(dev_priv);
	} else if (!resuming) {
		dev_info(&dev_priv->pdev->dev, "camera recovered\n");
	}
	fthd_schedule_idle(dev_priv);
out:
	mutex_unlock(&dev_priv->vb2_queue_lock);
}

void fthd_schedule_recovery(struct fthd_private *dev_priv)
{
	queue_work(system_dfl_wq, &dev_priv->recover_work);
}

static void fthd_idle_work(struct work_struct *work)
{
	struct fthd_private *dev_priv =
		container_of(to_delayed_work(work), struct fthd_private, idle_work);

	mutex_lock(&dev_priv->vb2_queue_lock);
	/* Streaming, suspend and remove look after the chip themselves */
	if (!dev_priv->streaming && !dev_priv->suspended && !dev_priv->removing)
		fthd_hw_power_down(dev_priv);
	mutex_unlock(&dev_priv->vb2_queue_lock);
}

/* Power the chip off once it has been idle for idle_poweroff_ms. */
void fthd_schedule_idle(struct fthd_private *dev_priv)
{
	int ms = READ_ONCE(idle_poweroff_ms);

	if (ms >= 0 && !dev_priv->streaming && !dev_priv->powered_off &&
	    !dev_priv->suspended && !dev_priv->removing)
		mod_delayed_work(system_dfl_wq, &dev_priv->idle_work,
				 msecs_to_jiffies(ms));
}

/*
 * The firmware stopped answering. Commands are refused from now on and the
 * recovery work restarts the chip; the macOS driver also answers a stalled
 * camera with a full power cycle. A failure during bring-up is handled by
 * the bring-up itself.
 */
void fthd_hw_hung(struct fthd_private *dev_priv, const char *why)
{
	if (cmpxchg(&dev_priv->hw_state, FTHD_HW_UP, FTHD_HW_FAILED) != FTHD_HW_UP)
		return;

	dev_priv->hang_count++;
	dev_err(&dev_priv->pdev->dev, "firmware not responding (%s)\n", why);
	fthd_schedule_recovery(dev_priv);
}

/*
 * Stop a chip that may still own buffers: without power it cannot write
 * into memory that is handed back to userspace. Called with vb2_queue_lock
 * held; the next stream start powers the chip up again.
 */
void fthd_hw_halt(struct fthd_private *dev_priv)
{
	if (dev_priv->hw_state == FTHD_HW_UP)
		dev_priv->hw_state = FTHD_HW_FAILED;
	fthd_hw_power_down(dev_priv);
}

static void fthd_pci_remove(struct pci_dev *pdev)
{
	struct fthd_private *dev_priv;

	dev_priv = pci_get_drvdata(pdev);
	if (!dev_priv)
		goto out;

	mutex_lock(&dev_priv->vb2_queue_lock);
	dev_priv->removing = true;
	mutex_unlock(&dev_priv->vb2_queue_lock);
	cancel_work_sync(&dev_priv->recover_work);
	cancel_delayed_work_sync(&dev_priv->idle_work);

	fthd_debugfs_exit(dev_priv);

	mutex_lock(&dev_priv->vb2_queue_lock);
	fthd_hw_teardown(dev_priv);
	/* The next probe expects a powered camera with its BARs set up */
	fthd_power_restore(dev_priv);
	mutex_unlock(&dev_priv->vb2_queue_lock);

	/*
	 * A firmware stop that timed out in the teardown queued a recovery;
	 * it must not run once dev_priv is freed, and neither may a frame
	 * watchdog that is still pending.
	 */
	cancel_work_sync(&dev_priv->recover_work);
	cancel_delayed_work_sync(&dev_priv->frame_watchdog);

	fthd_v4l2_unregister(dev_priv);

	pci_set_drvdata(pdev, NULL);
	fthd_irq_uninstall(dev_priv);
	pci_disable_msi(pdev);
	fthd_pci_unmap(dev_priv);
	kfree(dev_priv->pci_state);
	kfree(dev_priv);
out:
	pci_disable_device(pdev);
}

static int fthd_pci_init(struct fthd_private *dev_priv)
{
	struct pci_dev *pdev = dev_priv->pdev;
	int ret;


	ret = pci_enable_device(pdev);
	if (ret) {
		dev_err(&pdev->dev, "Failed to enable device\n");
		return ret;
	}

	/* ASPM must be disabled on the device or it hangs while streaming */
	pci_disable_link_state(pdev, PCIE_LINK_STATE_L0S | PCIE_LINK_STATE_L1 |
			       PCIE_LINK_STATE_CLKPM);

	ret = fthd_pci_reserve_mem(dev_priv);
	if (ret)
		goto fail_enable;

	ret = pci_enable_msi(pdev);
	if (ret) {
		dev_err(&pdev->dev, "Failed to enable MSI\n");
		goto fail_reserve;
	}

	ret = fthd_irq_install(dev_priv);
	if (ret)
		goto fail_msi;

	ret = fthd_pci_set_dma_mask(dev_priv, 64);
	if (ret)
		ret = fthd_pci_set_dma_mask(dev_priv, 32);

	if (ret)
		goto fail_irq;

	dev_info(&pdev->dev, "Setting %ubit DMA mask\n", dev_priv->dma_mask);
#if LINUX_VERSION_CODE < KERNEL_VERSION(5,18,0)
	pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(dev_priv->dma_mask));
#else
	dma_set_coherent_mask(&pdev->dev, DMA_BIT_MASK(dev_priv->dma_mask));
#endif

	pci_set_master(pdev);
	pci_set_drvdata(pdev, dev_priv);
	return 0;

fail_irq:
	fthd_irq_uninstall(dev_priv);
fail_msi:
	pci_disable_msi(pdev);
fail_reserve:
	pci_release_region(pdev, FTHD_PCI_S2_IO);
	pci_release_region(pdev, FTHD_PCI_S2_MEM);
	pci_release_region(pdev, FTHD_PCI_ISP_IO);
fail_enable:
	pci_disable_device(pdev);
	return ret;
}

static int fthd_pci_probe(struct pci_dev *pdev,
			  const struct pci_device_id *entry)
{
	struct fthd_private *dev_priv;
	int ret;

	dev_info(&pdev->dev, "Found FaceTime HD camera with device id: %x\n",
		 pdev->device);

	dev_priv = kzalloc(sizeof(struct fthd_private), GFP_KERNEL);
	if (!dev_priv) {
		dev_err(&pdev->dev, "Failed to allocate memory\n");
		return -ENOMEM;
	}

	dev_priv->ddr_model = 4;
	dev_priv->ddr_speed = 450;
	dev_priv->frame_rate = FTHD_FRAME_RATE_MAX;
	dev_priv->hw_state = FTHD_HW_DOWN;

	spin_lock_init(&dev_priv->io_lock);
	mutex_init(&dev_priv->vb2_queue_lock);

	mutex_init(&dev_priv->ioctl_lock);
	atomic_set(&dev_priv->users, 0);
	INIT_LIST_HEAD(&dev_priv->buffer_queue);
	INIT_WORK(&dev_priv->irq_work, fthd_irq_work);
	INIT_WORK(&dev_priv->recover_work, fthd_recover_work);
	INIT_DELAYED_WORK(&dev_priv->frame_watchdog, fthd_frame_watchdog);
	INIT_DELAYED_WORK(&dev_priv->idle_work, fthd_idle_work);

	dev_priv->pdev = pdev;

	ret = fthd_pci_init(dev_priv);
	if (ret)
		goto fail_work;

	/* Kept for restoring the config space after a power cycle */
	pci_save_state(pdev);
	dev_priv->pci_state = pci_store_saved_state(pdev);
	if (!dev_priv->pci_state) {
		ret = -ENOMEM;
		goto fail_pci;
	}

	ret = fthd_hw_bringup(dev_priv);
	if (ret)
		goto fail_pci;

	ret = fthd_v4l2_register(dev_priv);
	if (ret)
		goto fail_hw;

	ret = fthd_debugfs_init(dev_priv);
	if (ret)
		goto fail_v4l2;

	mutex_lock(&dev_priv->vb2_queue_lock);
	fthd_schedule_idle(dev_priv);
	mutex_unlock(&dev_priv->vb2_queue_lock);
	return 0;
fail_v4l2:
	fthd_v4l2_unregister(dev_priv);
fail_hw:
	fthd_hw_teardown(dev_priv);
fail_pci:
	pci_set_drvdata(pdev, NULL);
	fthd_irq_uninstall(dev_priv);
	pci_disable_msi(pdev);
	fthd_pci_unmap(dev_priv);
	pci_disable_device(pdev);
	kfree(dev_priv->pci_state);
fail_work:
	cancel_work_sync(&dev_priv->irq_work);
	kfree(dev_priv);
	return ret;
}

static int fthd_pm_suspend(struct device *dev)
{
	struct fthd_private *dev_priv = dev_get_drvdata(dev);

	mutex_lock(&dev_priv->vb2_queue_lock);
	dev_priv->suspended = true;
	mutex_unlock(&dev_priv->vb2_queue_lock);
	cancel_work_sync(&dev_priv->recover_work);
	cancel_delayed_work_sync(&dev_priv->idle_work);

	mutex_lock(&dev_priv->vb2_queue_lock);
	/* Queued buffers stay with the driver until the stream resumes */
	fthd_hw_teardown(dev_priv);
	/*
	 * The PCI core saves and restores the config space around sleep; an
	 * idle camera without power has none to save.
	 */
	fthd_power_restore(dev_priv);
	mutex_unlock(&dev_priv->vb2_queue_lock);
	return 0;
}

/*
 * In suspend-to-idle nothing else cuts the camera power; do it like the
 * macOS driver. With the config space saved here the PCI core leaves the
 * powered off device alone, and resume_noirq powers it on again before
 * pci_pm_resume() restores the config space.
 */
static int fthd_pm_suspend_noirq(struct device *dev)
{
	struct fthd_private *dev_priv = dev_get_drvdata(dev);

	if (pm_suspend_no_platform()) {
		pci_save_state(to_pci_dev(dev));
		fthd_power_off(dev_priv);
	}
	return 0;
}

static int fthd_pm_resume_noirq(struct device *dev)
{
	struct fthd_private *dev_priv = dev_get_drvdata(dev);

	if (!dev_priv->powered_off)
		return 0;

	if (fthd_power_on(dev_priv))
		dev_err(dev, "failed to power the camera on\n");
	else
		dev_priv->fresh_power = true;
	return 0;
}

static int fthd_pm_resume(struct device *dev)
{
	struct fthd_private *dev_priv = dev_get_drvdata(dev);

	mutex_lock(&dev_priv->vb2_queue_lock);
	dev_priv->suspended = false;
	dev_priv->resuming = true;
	mutex_unlock(&dev_priv->vb2_queue_lock);

	/* DDR training and firmware boot take most of a second */
	fthd_schedule_recovery(dev_priv);
	return 0;
}

static const struct dev_pm_ops fthd_pm_ops = {
	SYSTEM_SLEEP_PM_OPS(fthd_pm_suspend, fthd_pm_resume)
	NOIRQ_SYSTEM_SLEEP_PM_OPS(fthd_pm_suspend_noirq, fthd_pm_resume_noirq)
};

static const struct pci_device_id fthd_pci_id_table[] = {
	{ PCI_DEVICE(0x14e4, 0x1570), 4 },
	{ 0, },
};

static struct pci_driver fthd_pci_driver = {
	.name = KBUILD_MODNAME,
	.probe = fthd_pci_probe,
	.remove = fthd_pci_remove,
	.shutdown = fthd_pci_remove,
	.id_table = fthd_pci_id_table,
	.driver.pm = pm_sleep_ptr(&fthd_pm_ops),
};

module_pci_driver(fthd_pci_driver);

MODULE_FIRMWARE("facetimehd/firmware.bin");
MODULE_FIRMWARE("facetimehd/1222_01XX.dat");
MODULE_FIRMWARE("facetimehd/1571_01XX.dat");
MODULE_FIRMWARE("facetimehd/1575_01XX.dat");
MODULE_FIRMWARE("facetimehd/1671_01XX.dat");
MODULE_FIRMWARE("facetimehd/1674_01XX.dat");
MODULE_FIRMWARE("facetimehd/1675_01XX.dat");
MODULE_FIRMWARE("facetimehd/1771_01XX.dat");
MODULE_FIRMWARE("facetimehd/1871_01XX.dat");
MODULE_FIRMWARE("facetimehd/1874_01XX.dat");
MODULE_FIRMWARE("facetimehd/8221_01XX.dat");
MODULE_FIRMWARE("facetimehd/9112_01XX.dat");
MODULE_DEVICE_TABLE(pci, fthd_pci_id_table);
MODULE_AUTHOR("Patrik Jakobsson <patrik.r.jakobsson@gmail.com>");
MODULE_DESCRIPTION("FacetimeHD camera driver");

/*
 * A package build passes its version and a hash of these sources, so that
 * the loaded module (/sys/module/<name>/version) can be traced to its source.
 */
#ifdef FTHD_SRCID
MODULE_VERSION(FTHD_SRCID);
#endif
MODULE_LICENSE("GPL");
